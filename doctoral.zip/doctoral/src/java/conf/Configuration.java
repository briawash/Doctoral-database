package conf;

/**
 * DB Configuration
 */
public class Configuration {
    public static final String HOST = "localhost";
    public static final String PORT = "3307";
    public static final String DATABASE = "doctoral";
    public static final String USER = "root";
    public static final String PASSWORD = "123456";
}
